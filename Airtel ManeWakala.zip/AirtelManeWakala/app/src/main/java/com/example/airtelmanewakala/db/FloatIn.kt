package com.example.airtelmanewakala.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "floatin_table")
data class FloatIn (
        @PrimaryKey(autoGenerate = true)
        @ColumnInfo(name="floatinid")
        val floatinid: Int,
        @ColumnInfo(name="transid")
        val transid: String,
        @ColumnInfo(name="amount")
        val amount: String,
        @ColumnInfo(name="balance")
        val balance: String,
        @ColumnInfo(name="wakalaidkey")
        val wakalaidkey: String,
        @ColumnInfo(name="status")
        val status: Int,
        @ColumnInfo(name="wakalaorder")
        val wakalaorder: String,
        @ColumnInfo(name="comment")
        val comment: String,
        @ColumnInfo(name="wakalacode")
        val wakalacode: String,
        @ColumnInfo(name="wakalamkuunumber")
        val wakalamkuunumber: String,
        @ColumnInfo(name="wakalaname")
        val wakalaname: String,
        @ColumnInfo(name="wakalanumber")
        val wakalanumber: String,
        @ColumnInfo(name="createdAt")
        val createdAt: Long,
        @ColumnInfo(name="modifiedAt")
        val modifiedAt: Long,

)