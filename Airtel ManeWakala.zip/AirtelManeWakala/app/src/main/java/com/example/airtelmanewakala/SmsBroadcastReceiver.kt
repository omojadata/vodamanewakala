package com.example.airtelmanewakala

import android.annotation.TargetApi
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsMessage
import android.util.Log
import androidx.annotation.RequiresApi

class SmsBroadcastReceiver : BroadcastReceiver() {
    //    private val TAG = 'MY'
    private val TAG = "boadcast"
    val pdu_type = "pdus"
    @RequiresApi(Build.VERSION_CODES.O)
    @TargetApi(Build.VERSION_CODES.M)
    override fun onReceive(context: Context?, intent: Intent) {
        // Get the SMS message.
        val bundle = intent.extras
        val msgs: Array<SmsMessage?>
        var strMessage = ""
        val format = bundle!!.getString("format")
        // Retrieve the SMS message received.
        val pdus = bundle[pdu_type] as Array<Any>?
        if (pdus != null) {
            // Check the Android version.
            val isVersionM = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            // Fill the msgs array.
            msgs = arrayOfNulls(pdus.size)
            for (i in msgs.indices) {
                // Check Android version and use appropriate createFromPdu.
                if (isVersionM) {
                    // If Android version M or newer:
                    msgs[i] = SmsMessage.createFromPdu(pdus[i] as ByteArray, format)
                } else {
                    // If Android version L or older:
                    msgs[i] = SmsMessage.createFromPdu(pdus[i] as ByteArray)
                }

                // Build the message to show.
                var strAddress = (msgs[i]?.originatingAddress)
                var strBody = (msgs[i]?.messageBody)
                var strTime = (msgs[i]?.timestampMillis)
                // Log and display the SMS message.
                Log.d("TAGG", "onReceive: $strMessage, $strTime")

                val intent1 = Intent(context!!.applicationContext, ForegroundSmsService::class.java)
                intent1.putExtra("smsadress",strAddress)
                intent1.putExtra("smsbody",strBody)
                intent1.putExtra("smstime",strTime)
                context!!.applicationContext.startForegroundService(intent1)

            }
        }
    }


}