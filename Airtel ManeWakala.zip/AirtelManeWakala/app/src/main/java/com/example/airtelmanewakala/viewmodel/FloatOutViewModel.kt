package com.example.airtelmanewakala.viewmodel

import android.util.Log
import androidx.databinding.Bindable
import androidx.databinding.Observable
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.airtelmanewakala.db.FloatOut
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.network.RetroInstance
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FloatOutViewModel ( private val repository: MobileRepository): ViewModel(), Observable  {
    val modifiedAt = System.currentTimeMillis().toInt()+60000
    val floatOut=repository.floatOut
    val floatOutFilterZero= repository.floatOutFilter(0)
    val floatOutFilterOne= repository.floatOutFilter2(1,modifiedAt)
    val floatOutFilterTwo= repository.floatOutFilter(2)
    val floatOutFilterThree= repository.floatOutFilter(3)
    @Bindable
    val allButton = MutableLiveData<String>()
    val zeroButton = MutableLiveData<String>()
    val oneButton = MutableLiveData<String>()
    val twoButton = MutableLiveData<String>()
    val threeButton = MutableLiveData<String>()
    val uploadButton = MutableLiveData<String>()

    init {
        allButton.value= "A"
    }
    init {
        zeroButton.value= "Pnd"
    }
    init {
        oneButton.value= "Ussd"
    }
    init {
        twoButton.value= "Done"
    }
    init {
        threeButton.value= "N/O"
    }

    init {
        uploadButton.value= "UP"
    }

    @Bindable
    val getButtonText=MutableLiveData<String>()

    init {
        getButtonText.value= "FETCH FLOATOUT"
    }


    fun insert(floatout: List<FloatOut>): Job =
        viewModelScope.launch {
            repository.insertFloatOutTest(floatout)
        }

    fun onGetButton() {
        val service= RetroInstance.getRetroInstance()
        val retrofitData = service?.getDataFloatOut()

        if (retrofitData != null) {
            retrofitData.enqueue(object : Callback<List<FloatOut>> {
                override fun onResponse(
                    call: Call<List<FloatOut>>,
                    response: Response<List<FloatOut>>
                ) {
                    val responseBody =response.body()
                    if (responseBody != null) {
                        insert(responseBody)
                    }

                    Log.d("WAKALAmy", "oKEY")
                }




                override fun onFailure(call: Call<List<FloatOut>>, t: Throwable) {
                    TODO("Not yet implemented")
                }
            })
        }
        else{
            Log.d("WAKALA", "omNull")
        }
    }


    override fun addOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }

    override fun removeOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }
}