package com.example.airtelmanewakala.RecyclerView

import android.graphics.Color
import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.airtelmanewakala.R
import com.example.airtelmanewakala.databinding.FloatinitemlistBinding
import com.example.airtelmanewakala.db.FloatIn
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

//class RecyclerViewWakalaMkuu(private val wakalaMkuuList:List<WakalaMkuu>):RecyclerView.Adapter<MyWakalaMkuuViewHolder>()

class RecyclerViewFloatIn(private val floatInList: List<FloatIn>,
                          private val clickListener: (FloatIn)->Unit): RecyclerView.Adapter<MyFloatInViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyFloatInViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding: FloatinitemlistBinding= DataBindingUtil.inflate(
            layoutInflater,
            R.layout.floatinitemlist,
            parent,
            false
        )
        return MyFloatInViewHolder(binding)
//        val binding: FloatoutitemlistBinding = DataBindingUtil.inflate(layoutInflater,
//            R.layout.floatoutitemlist,parent,false)
//        return  MyFloatOutViewHolder(binding)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: MyFloatInViewHolder, position: Int) {
//        holder.bind(wakalaList[position])
        holder.bind(floatInList[position],clickListener)
//        holder.bind(floatOutList[position],clickListener)
    }

    override fun getItemCount(): Int {
      return floatInList.size
    }


}

class MyFloatInViewHolder(val binding: FloatinitemlistBinding):RecyclerView.ViewHolder(binding.root){
 @RequiresApi(Build.VERSION_CODES.O)
 fun bind(floatIn: FloatIn, clickListener: (FloatIn)->Unit){
//     val bus: String = mData.get(position)
//     holder.busStopName.setText(bus)
     if (floatIn.status == 0) {
         binding.floatincardView.setCardBackgroundColor(Color.parseColor("#add8e6"))
         // Set text color what should be for Bus left
     } else if (floatIn.status == 1) {
         binding.floatincardView.setCardBackgroundColor(Color.parseColor("#00ab66"))
         // Set text color what should be for upcoming buses
     } else if (floatIn.status == 2) {
       binding.floatincardView.setCardBackgroundColor(Color.parseColor("#ffa500"))
         // Set text color what should be for upcoming buses
     } else if (floatIn.status == 3) {
         binding.floatincardView.setCardBackgroundColor(Color.parseColor("#ff0f0f"))
         // Set text color what should be for upcoming buses
     }

     binding.sectionone.text="Amount -"+floatIn.amount+"\n"+floatIn.comment+"\n"+floatIn.transid+"\n"+getdate(floatIn.createdAt)
     binding.sectiontwo.text=floatIn.wakalaname+"\n"+floatIn.wakalanumber
     binding.sectionthree.text=floatIn.wakalaorder+"\n"+getdate(floatIn.modifiedAt)
     binding.listItemLayout.setOnClickListener {
         clickListener(floatIn)
     }
 }
    @RequiresApi(Build.VERSION_CODES.O)
    fun getdate(created:Long): String? {
        val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        val instant = Instant.ofEpochMilli(created)
        val date = LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
        return formatter.format(date).toString()
    }


}
//class MyWakalaMkuuViewHolder(val binding: WakalamkuuitemlistBinding):RecyclerView.ViewHolder(binding.root){
//
//    fun bind(wakalaMkuu: WakalaMkuu){
//        binding.wakalamkuuHalopesa.text=wakalaMkuu.halopesa
//        binding.wakalamkuuMpesa.text=wakalaMkuu.mpesa
//        binding.wakalamkuuTigopesa.text=wakalaMkuu.tigopesa
//        binding.wakalamkuuTpesa.text=wakalaMkuu.tpesa
//    }
//}