package com.example.airtelmanewakala

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.telephony.TelephonyManager.UssdResponseCallback
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.example.airtelmanewakala.db.*
import com.romellfudi.ussdlibrary.SplashLoadingService
import com.romellfudi.ussdlibrary.USSDApi
import com.romellfudi.ussdlibrary.USSDController
import kotlinx.coroutines.*
import java.util.*
import kotlin.collections.HashMap
import kotlin.collections.HashSet


class ForegroundSmsService : Service() {
    lateinit var smsreceiver: SmsBroadcastReceiver
    private val scope = CoroutineScope(Dispatchers.Main)
    private val TAG = "MyService"
    private val CHANNELID = "ForegroundService Kotlin"


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        createNotificationChannel()
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0, notificationIntent, 0
        )
        val notification = NotificationCompat.Builder(this, CHANNELID)
            .setContentTitle("MOBILE AIRTEL IS ACTIVE")
            .setContentText("input")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .build()
        startForeground(1, notification)

        val smsAddress = intent?.getStringExtra("smsadress")
        val smsbody = intent?.getStringExtra("smsbody")
        val smsTime = intent?.getLongExtra("smstime", 0)
        var firstword = smsbody?.let { filterBody(it.toLowerCase(), 1) }
        var mtandao = "+255657003016"
        var mtandaoname = "AIRTEL"
        val errornumber = "+255683071757"
        val contactnumber = "0711363627"
        val createdAt = System.currentTimeMillis()
        val modifiedAt = System.currentTimeMillis()

        //do heavy work on a background thread
        scope.launch {

            val dao = MoblieDatabase.getInstance(application).MobileDAO
            val repository = MobileRepository(dao)
            val time = smsTime!!.toInt()
            val sms = SmsManager.getDefault()

            val map = HashMap<String, HashSet<String>>()
            map["KEY_LOGIN"] = HashSet(Arrays.asList("espere", "waiting", "loading", "esperando"))
            map["KEY_ERROR"] = HashSet(Arrays.asList("problema", "problem", "error", "null"))
            if (smsAddress == mtandao) {
                if (firstword == "umepokea") {
                    var balancedata = smsbody?.let { filterBody(it, 8) }
                    var balancedata2 = balancedata?.let { filter(it) }
                    var balance = balancedata2.toString()

                    var amountdata = smsbody?.let { filterBody(it, 2) }
                    var amoutdata2 = amountdata?.let { filter(it) }
                    var amount = amoutdata2.toString()

                    var namedata = smsbody?.let { it.substringAfter("kutoka") }
                    var namedata2 = namedata?.let {
                        it.substringAfter(",").substringBefore(". Salio").replace(
                            "\\s+".toRegex(), " "
                        )
                    }
                    var name = namedata2.toString()

                    var id = smsbody?.let { it.substringAfter("Muamala No: ") }
                    var transid = id.toString()

                    //CHECK IF TRANSACTION EXISTS
                    val searchFloatInId = repository.searchFloatInId(transid)
                    if (searchFloatInId == null) {

                        //BALANCE FUNTION
                        checkbalancefunction(balance, amount, name, 1, time.toString())
                        Log.i(
                            "TAXT",
                            name
                        )
                        //CHECK IF WAKALA EXISTS
                        val searchWakala = repository.searchWakala(name)
                        if (searchWakala != null) {
                            val wakalaKeyId = searchWakala.wakalaid
                            val wakalacontact = searchWakala.contact
                            val wakalaname = searchWakala.airtelname
                            var currentamount = amount.toInt()
                            val maxAmount = searchWakala.maxamount.toInt()

                            //CHECK IF FLOAT IN AMOUNT LESS OR EQUAL TO MAX AMOUNT
                            if (currentamount <= maxAmount) {

                                //INSERT FLOATIN STATUS 0( WAITING ORDER)
                                val insertFloatIn = iFloatIn(
                                    transid,
                                    amount,
                                    balance,
                                    wakalaKeyId,
                                    0,
                                    wakalaname,
                                    wakalacontact,
                                    "WAITING ORDER",
                                    createdAt,
                                    modifiedAt
                                )

                                //CHECK IF FLOATIN INSERTED
                                if (insertFloatIn != null) {
                                    //SEND TEXT TO WAKALA OF ORDER IF FLOAT IN INSERTED
                                    var SmsText = "$amount $transid ya $mtandao itumwe wapi?"
                                    sendsms(wakalacontact, SmsText)

                                } else {
                                    //SEND ERROR TEXT TO ERROR NUMBER IF FLOATIN NOT INSERTED
                                    var SmsText = "ERROR OUR WAKALA NOT INSERTED FLOATIN"
                                    sendsms(errornumber, SmsText)

                                }
                            } else {
                                //INSERT FLOATIN STATUS 2(LARGE ORDER)
                                val insertFloatIn = iFloatIn(
                                    transid,
                                    amount,
                                    balance,
                                    wakalaKeyId,
                                    2,
                                    wakalaname,
                                    wakalacontact,
                                    "LARGE ORDER",
                                    createdAt,
                                    modifiedAt
                                )

                                //CHECK IF FLOATIN INSERTED
                                if (insertFloatIn != null) {
                                    async {

                                        //SEND TEXT TO WAKALA OF ORDER TOO LARGE IF FLOAT IN INSERTED
                                        var SmsText =
                                            "$amount $transid ya $mtandao uliyotuma ni zaidi ya kiima ulichowekewa.Piga namba $contactnumber kwa msaada"
                                        sendsms(wakalacontact, SmsText)

                                        //SEND ERROR TEXT TO ERROR NUMBER OF LARGE AMOUNT INSERTED
                                        var SmsText2 =
                                            "ERROR OUR WAKALA INSERTED FLOATIN:OVERAMOUNT.:$smsbody"
                                        sendsms(errornumber, SmsText2)
                                    }
                                } else {

                                    //SEND ERROR TEXT TO ERROR NUMBER IF FLOATIN LARGE AMOUNT NOT INSERTED
                                    var SmsText =
                                        "ERROR OUR WAKALA NOT INSERTED FLOATIN:OVERAMOUNT.:$smsbody"
                                    sendsms(errornumber, SmsText)
                                }
                            }

                        } else {

                            //INSERT FLOATIN STATUS 3(UNKWOWN WAKALA)
                            val insertFloatIn = iFloatIn(
                                transid,
                                amount,
                                balance,
                                "",
                                3,
                                "",
                                "",
                                "UNKWOWN WAKALA",
                                createdAt,
                                modifiedAt
                            )

                            //CHECK IF FLOATIN INSERTED
                            if (insertFloatIn != null) {

                                //SEND ERROR TEXT TO ERROR NUMBER IF FLOATIN UNKNOWN WAKALA INSERTED
                                var SmsText = "ERROR NOT OUR WAKALA INSERTED FLOATIN: $smsbody"
                                sendsms(errornumber, SmsText)

                            } else {

                                //SEND ERROR TEXT TO ERROR NUMBER IF FLOATIN UNKNOWN WAKALA  NOT INSERTED
                                var SmsText = "ERROR NOT OUR WAKALA NOT INSERTED FLOATIN"
                                sendsms(errornumber, SmsText)
                            }
                        }

                    } else {

                        //SEND ERROR TEXT TO ERROR NUMBER OF FLOAT IN TRANSACTION ALREADY EXISTS
                        var SmsText = "ERROR FLOATIN TRANSACTION ALREADY EXISTS"
                        sendsms(errornumber, SmsText)
                    }
                } else if (firstword == "umetuma") {

                    var balancedata = smsbody?.let { filterBody(it, 7) }
                    var balancedata2 = balancedata?.let { filter(it) }
                    var balance = balancedata2.toString()

                    var amountdata = smsbody?.let { filterBody(it, 2) }
                    var amoutdata2 = amountdata?.let { filter(it) }
                    var amount = amoutdata2.toString()

                    var namedata = smsbody?.let { it.substringAfter("kwa") }
                    var namedata2 = namedata?.let {
                        it.substringAfter(",").substringBefore(". Salio").replace(
                            "\\s+".toRegex(), " "
                        )
                    }
                    var name = namedata2.toString()

                    var id =
                        smsbody?.let { it.substringAfter("Muamala No.").substringBefore(".Tuma ") }
                    var transid = id.toString()

                    //CHECK IF TRANSACTION(transactionid) EXISTS
                    val searchFloatOutId = repository.searchFloatOutId(transid)
                    if (searchFloatOutId != null) {
                        //BALANCE FUNTION
                        checkbalancefunction(balance, amount, name, 2, time.toString())

                        //CHECK IF WAKALA EXISTS
                        val searchWakala = repository.searchWakalaAirtel(name)
                        if (searchWakala != null) {

                            // CHECK IF TRANSACTION (floatinid) EXISTS
                            val searchFloatOutId2 = repository.searchFloatOutId2(name)
                            if (searchFloatOutId2 != null) {
                                //UPDATE FLOATOUT STATUS 2(DONE)
                                val wakalaKeyId = searchWakala.wakalaid
                                val updateFloatOut = uFloatOut(
                                    2,
                                    amount,
                                    wakalaKeyId,
                                    transid,
                                    "DONE",
                                    modifiedAt
                                )
                                if (updateFloatOut != null) {
                                    // SUCCESS
                                } else {
                                    //SEND ERROR TEXT TO ERROR NUMBER IF FLOATOUT OUR WAKALA NOT UPDATED
                                    var sendSms = "ERROR OUR WAKALA NOT UPDATED FLOATOUT"
                                    sendsms(errornumber, sendSms)
                                }
                            } else {
                                async {
                                    //INSERT FLOATOUT STATUS 4(UNKWOWN ORDER)
                                    val insertFloatOut = iFloatOut(
                                        transid,
                                        amount,
                                        name,
                                        "",
                                        "",
                                        "",
                                        0,
                                        "",
                                        4,
                                        "NO ORDER",
                                        "",
                                        createdAt,
                                        modifiedAt
                                    )
                                    //SEND ERROR TEXT TO ERROR NUMBER IF FLOATOUT OUR WAKALA NOT ORDERED
                                    var sendSms = "ERROR TRANSACTION NEVER INSERTED VIA FLOATOUT"
                                    sendsms(errornumber, sendSms)
                                }
                            }

                        } else {
                            async {
                                //INSERT FLOATOUT STATUS 3(UNKWOWN WAKALA)
                                val insertFloatOut = iFloatOut(
                                    transid,
                                    amount,
                                    name,
                                    "",
                                    "",
                                    "",
                                    0,
                                    "",
                                    3,
                                    "NOT OURS",
                                    "",
                                    createdAt,
                                    modifiedAt
                                )
                                //SEND ERROR TEXT TO ERROR NUMBER IF FLOATOUT NOT OUT WAKALA INSERTED
                                var sendSms = "ERROR NOT OUR WAKALA INSERTED FLOATOUT $smsbody"
                                sendsms(errornumber, sendSms)
                            }
                        }
                    } else {
                        //SEND ERROR TEXT TO ERROR NUMBER OF FLOAT IN TRANSACTION ALREADY EXISTS
                        var SmsText = "ERROR FLOATIN TRANSACTION ALREADY EXISTS"
                        sendsms(errornumber, SmsText)
                    }
                } else {
                    //SEND ERROR TEXT TO ERROR NUMBER OF NETWORK CHANGES/NEW
                    var SmsText = "ERROR SOMETING CHANGED IN $mtandao"
                    sendsms(errornumber, SmsText)
                }
            } else {
                if (firstword == "wakalamkuu") {
                    //'WAKALAMKUU' 'halopesa' 100000 WAKALACODE WAKALANAME FLOATINTRANSID wakalano $mtandaoname
                    var network2 = smsbody?.let { filterBody(it, 2) }
                    var network = network2.toString()

                    var fromnetwork2 = smsbody?.let { filterBody(it, 8) }
                    var fromnetwork = fromnetwork2.toString()

                    var phone2 = smsAddress?.let { it }
                    var phone = phone2.toString()

                    var wakalacode2 = smsbody?.let { filterBody(it, 4) }
                    var wakalacode = wakalacode2.toString()

                    var amount2 = smsbody?.let { filterBody(it, 3) }
                    var amount = amount2.toString()

                    var wakalaname2 = smsbody?.let { filterBody(it, 5) }
                    var wakalaname = wakalaname2.toString()

                    var floatinid2 = smsbody?.let { filterBody(it, 6) }
                    var floatinid = floatinid2.toString()

                    var wakalano2 = smsbody?.let { filterBody(it, 7) }
                    var wakalano = wakalano2.toString()

                    //CHECK IF TRANSACTION EXISTS
                    val searchFloatOutWakalaId = repository.searchFloatOutId3(floatinid)
                    if (searchFloatOutWakalaId == null) {

                        //CHECK IF WAKALA MKUU EXISTS AND GET ID
                        val searchWakalaMkuu = when (network) {
                            "tigopesa" -> repository.searchWakalaMkuuTigo(phone).wakalamkuuid
                            "mpesa" -> repository.searchWakalaMkuuVoda(phone).wakalamkuuid
                            "tpesa" -> repository.searchWakalaMkuuTtcl(phone).wakalamkuuid
                            "airtelmoney" -> repository.searchWakalaMkuuAirtel(phone).wakalamkuuid
                            "halopesa" -> repository.searchWakalaMkuuHalotel(phone).wakalamkuuid
                            else -> ""
                        }

                        if (searchWakalaMkuu != null) {

                            //CHECK IF WAKALA EXISTS AND GET CODE
                            val searchWakalaCode = when (network) {
                                "tigopesa" -> repository.searchWakalaTigo(wakalacode).tigopesa
                                "mpesa" -> repository.searchWakalaVoda(wakalacode).mpesa
                                "tpesa" -> repository.searchWakalaTtcl(wakalacode).tpesa
                                "airtelmoney" -> repository.searchWakalaAirtel(wakalacode).airtelmoney
                                "halopesa" -> repository.searchWakalaHalotel(wakalacode).halopesa
                                else -> ""
                            }
                            val searchWakalaName = when (network) {
                                "tigopesa" -> repository.searchWakalaTigo(wakalacode).tigoname
                                "mpesa" -> repository.searchWakalaVoda(wakalacode).vodaname
                                "tpesa" -> repository.searchWakalaTtcl(wakalacode).ttclname
                                "airtelmoney" -> repository.searchWakalaAirtel(wakalacode).airtelname
                                "halopesa" -> repository.searchWakalaHalotel(wakalacode).haloname
                                else -> ""
                            }
                            if (searchWakalaCode != null && searchWakalaName != null) {
                                var wakalamkuuid = searchWakalaMkuu
                                //INSERT FLOATOUT STATUS 0(PENDING)
                                val insertFloatOut = iFloatOut(
                                    "",
                                    amount,
                                    wakalaname,
                                    wakalacode,
                                    fromnetwork,
                                    "",
                                    wakalamkuuid.toInt(),
                                    floatinid,
                                    0,
                                    "PENDING",
                                    wakalano,
                                    createdAt,
                                    modifiedAt
                                )

                                if (insertFloatOut != null) {
                                    //CHECK BALANCE
                                    var balanci = repository.getBalance().balance.toInt()
                                    if (balanci >= amount.toInt()) {
                                        //DAILL USSD
//                                        sendsms(errornumber, "DAILING")
                                        dialUssdToGetPhoneNumber3("*150*01#", wakalacode, amount,modifiedAt,floatinid)
                                    } else {
                                        var SmsText = "HAMNA SALIO BALANCE NI:{$balanci}"
                                        sendsms(errornumber, SmsText)
                                    }

                                } else {
                                    //send error text to wakala error number wakala float out not inserted
                                    var SmsText = "ERROR OUR WAKALA NOT INSERTED FLOATOUT"
                                    sendsms(errornumber, SmsText)
                                    //SEND ERROR... OUR WAKALA NOT INSERTED FLOATOUT
                                }
                            } else {
                                //SEND ERROR... NOT OUR WAKALA
                                var SmsText = "ERROR NOT OUR WAKALA$smsbody"
                                sendsms(errornumber, SmsText)

                            }
                        } else {
//SEND ERROR... NOT OUR WAKALA MKUU
                            var SmsText = "ERROR NOT OUR WAKALA MKUU $smsAddress,$smsbody"
                            sendsms(errornumber, SmsText)
                                                    }
                    } else {
                        var SmsText = "ERROR WAKALA MKUU TRNSACTION DUPLICATE ,$smsbody"
                        sendsms(errornumber, SmsText)
//                        sendsms(errornumber, "SmsText")
                    }

                } else if (firstword == "tigopesa" || firstword == "mpesa" || firstword == "halopesa" || firstword == "tpesa") {
                    var phone2 = filterNumber(smsAddress.toString())
                    var phone = phone2
                    //seacrh contact name
                    val searchWakala = repository.searchWakalaContact(phone)

                    if (searchWakala != null) {
                        //CHECK IF THERE IS UNSERVED FLOATIN ORDER
                        val searchFloatInId2 = repository.searchFloatInId2(searchWakala.wakalaid)
                        if (searchFloatInId2 != null) {

                            val wakalamkuunumber = when (firstword) {
                                "tigopesa" -> repository.getWakalaMkuu().tigopesa
                                "mpesa" -> repository.getWakalaMkuu().mpesa
                                "tpesa" -> repository.getWakalaMkuu().tpesa
                                "halopesa" -> repository.getWakalaMkuu().halopesa
                                else -> ""
                            }
                            val wakalacode = when (firstword) {
                                "tigopesa" -> searchWakala.tigopesa
                                "mpesa" -> searchWakala.mpesa
                                "tpesa" -> searchWakala.tpesa
                                "halopesa" -> searchWakala.halopesa
                                else -> ""
                            }

                            val wakalaname = when (firstword) {
                                "tigopesa" -> searchWakala.tigoname
                                "mpesa" -> searchWakala.vodaname
                                "tpesa" -> searchWakala.ttclname
                                "halopesa" -> searchWakala.haloname
                                else -> ""
                            }

                            val wakalano = searchFloatInId2.wakalanumber

                            val floatinid = searchFloatInId2.floatinid

                            val amount = searchFloatInId2.amount
                            //UPDATE FLOATIN WITH ORDER(STATUS 1= ODERSENT)
                            val updateFloatIn = repository.updateFloatIn(
                                1,
                                floatinid,
                                firstword,
                                "ORDERSENT",
                                wakalacode,
                                wakalamkuunumber,
                                wakalaname,
                                modifiedAt
                            )
                            if (updateFloatIn != null) {
                                //SENT ORDER TEXT TO WAKALAMKUU
                                var SmsText =
                                    "WAKALAMKUU $firstword $amount $wakalacode $wakalaname $floatinid $wakalano $mtandaoname"
                                sendsms(wakalamkuunumber, SmsText)
                            } else {
                                // SEND ERROR... OUR WAKALA ORDER NOT UPDATED FLOATOUT
                                var SmsText = "ERROR NOT OUR WAKALA NOT INSERTED FLOATIN $smsbody"
                                sendsms(errornumber, SmsText)
                            }
                        } else {
                            var SmsText = "ERROR ORDER HAS NO FLOATIN $smsbody"
                            sendsms(errornumber, SmsText)
                            // SEND ERROR...NO TRANSACTION FLOATIN
                        }

                    } else {
                        var SmsText = "ERROR NOT OUR WAKALA WITH ORDER"
                        sendsms(errornumber, SmsText)

                    }
                } else if (firstword == "airtelmoney") {
                    var sendSms = "ERROR OUR WAKALA WITH ORDER SAME NETWORK ODER $smsbody"
                    sendsms(errornumber, sendSms)
                }
            }
        }

        return START_NOT_STICKY;
    }


    override fun onBind(intent: Intent?): IBinder? {
        TODO("Not yet implemented")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNELID, "Foreground Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager!!.createNotificationChannel(serviceChannel)
        }
    }

    private fun filterBody(str: String, n: Int): String {
        val word = str.split(" ")[n - 1]
        return word
    }

    private fun filterNumber(str: String): String {
        val str2 = str.replace("+255", "0")
        return str2
    }

    private fun filter(str: String): String {
        val word = Regex("[^0-9 ]")
        val words = word.replace(str, "")
        return words.substring(0, words.length - 2)
    }

    suspend fun checkbalancefunction(
        balance: String,
        amount: String,
        name: String,
        status: Int,
        time: String
    ) {
        scope.launch {
            val dao = MoblieDatabase.getInstance(application).MobileDAO
            val repository = MobileRepository(dao)

            async {
                //INSERT BALANCE
                repository.insertBalance(
                    Balance(
                        0,
                        balance,
                        amount,
                        name,
                        status,
                        time.toLong()
                    )
                )
                //CHECK BALANCE
                var balanci = repository.getBalance().balance.toInt()
                if (balanci < 50000) {
                    //send balance error
                }

            }
        }
    }

    suspend fun iFloatIn(
        transid: String,
        amount: String,
        balance: String,
        wakalaidkey: String,
        status: Int,
        wakalaname: String,
        wakalacontact: String,
        comment: String,
        createdAt: Long,
        modifiedAt: Long
    ) {
        val dao = MoblieDatabase.getInstance(application).MobileDAO
        val repository = MobileRepository(dao)
        repository.insertFloatIn(
            FloatIn(
                0,
                transid,
                amount,
                balance,
                wakalaidkey,
                status,
                "",
                comment,
                "",
                "",
                wakalaname,
                wakalacontact,
                createdAt,
                modifiedAt
            )
        )
    }

    suspend fun uFloatOut(
        status: Int,
        amount: String,
        wakalaKeyId: String,
        transid: String,
        comment: String,
        modifiedAt: Long
    ) {

        val dao = MoblieDatabase.getInstance(application).MobileDAO
        val repository = MobileRepository(dao)
        repository.updateFloatOut(
            status,
            amount,
            wakalaKeyId,
            transid,
            comment,
            modifiedAt
        )

    }

    suspend fun iFloatOut(
        transid: String,
        amount: String,
        name: String,
        code: String,
        network: String,
        wakalaKeyId: String,
        wakalamkuu: Int,
        floatinid: String,
        status: Int,
        comment: String,
        wakalanumber: String,
        createdAt: Long,
        modifiedAt: Long
    ) {

        val dao = MoblieDatabase.getInstance(application).MobileDAO
        val repository = MobileRepository(dao)
        repository.insertFloatOut(
            FloatOut(
                0,
                transid,
                amount,
                name,
                code,
                network,
                wakalaKeyId,
                wakalamkuu,
                floatinid,
                status,
                comment,
                wakalanumber,
                createdAt,
                modifiedAt
            )
        )
    }

    fun sendsms(number: String, smstext: String) {
        val sms = SmsManager.getDefault()
        val parts: ArrayList<String> = sms.divideMessage(smstext)
        sms.sendMultipartTextMessage(
            number,
            null,
            parts,
            null,
            null
        )
    }


    fun dialUssdToGetPhoneNumber3(ussdCode: String, wakalano: String, amount: String,modifiedAt:Long,floatinid:String) {
        var svc = Intent(applicationContext, SplashLoadingService::class.java)
        application.startService(svc)
        val map = HashMap<String, HashSet<String>>()
        map["KEY_LOGIN"] = HashSet(Arrays.asList("USSD code running..."))
        map["KEY_ERROR"] = HashSet(Arrays.asList("problema", "problem", "error", "null"))
        val ussdApi: USSDApi = USSDController.getInstance(this)
        ussdApi.callUSSDOverlayInvoke(ussdCode, map!!, object : USSDController.CallbackInvoke {

            override fun responseInvoke(message: String) {
                // message has the response string data
                ussdApi!!.send("6") { // it: response response
                    // second option list - select option 1
                    ussdApi.send("3") { // it: response message
                        ussdApi.send(wakalano) { // it: response message
                            Log.i(
                                "TAX",
                                message
                            )
                            ussdApi.send("100") { // it: response message
                                Log.i(
                                    "TAX",
                                    message
                                )
                                ussdApi.send("6499") { // it: response message
                                    //set databe true
                                    val dao = MoblieDatabase.getInstance(application).MobileDAO
                                    val repository = MobileRepository(dao)
                                    scope.launch {
                                        repository.updateFloatOut2(2,amount,floatinid,"USSD",modifiedAt)
                                    }
                                    Log.i(
                                        "TAX",
                                        message
                                    )
                                    application.stopService(svc);
                                }
                            }
                        }
                    }
                }
            }

            override fun over(message: String) {
                application.stopService(svc);8
                Log.i(
                    "TAZ",
                    message
                )
                // message has the response string data from USSD or error
                // response no have input text, NOT SEND ANY DATA
            }
        })
    }


    //    @RequiresApi(Build.VERSION_CODES.N)
    fun dialUssdToGetPhoneNumber(ussdCode: String) {
        Log.i(
            "TAJ",
            "onRe"
        )

        if (ussdCode.equals("", ignoreCase = true)) return
        val manager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CALL_PHONE
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.i(
                    "TAJ",
                    "onReceiveUssdResponse:  Ussd Response = "
                )
            }
            manager.sendUssdRequest(ussdCode, object : UssdResponseCallback() {
                override fun onReceiveUssdResponse(
                    telephonyManager: TelephonyManager,
                    request: String,
                    response: CharSequence
                ) {
                    super.onReceiveUssdResponse(telephonyManager, request, response)

                    Log.i(
                        "TAJ",
                        "onReceiveUssdResponse:  Ussd Response = " + response.toString()
                            .trim { it <= ' ' })
                }

                override fun onReceiveUssdResponseFailed(
                    telephonyManager: TelephonyManager,
                    request: String,
                    failureCode: Int
                ) {
                    super.onReceiveUssdResponseFailed(telephonyManager, request, failureCode)
                    Log.i("TAJ", "onReceiveUssdResponseFailed: $failureCode$request")
                }
            }, Handler(Looper.getMainLooper()))
        }

    }

}

