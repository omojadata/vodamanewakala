package com.example.airtelmanewakala.db

import androidx.lifecycle.LiveData

class MobileRepository(private val dao: MobileDAO) {

    //FLOATIN
    val floatIn=dao.floatIn()

    fun floatInFilter(status: Int): LiveData<List<FloatIn>> {
        return dao.floatInFilter(status)
    }

    suspend fun insertFloatIn(floatin: FloatIn){
        return dao.insertFloatIn(floatin)
    }

    suspend fun insertFloatInTest(floatin: List<FloatIn>){
        dao.insertFloatInTest(floatin)
    }

    suspend fun updateFloatIn(status: Int, floatinid: Int, wakalaorder:String,comment:String,wakalacode:String,wakalamkuunumber:String,wakalaname:String,modifiedat:Long):Int {
        return dao.updateFloatIn(status, floatinid,wakalaorder,comment,wakalacode,wakalamkuunumber,wakalaname,modifiedat)
    }

    suspend fun searchFloatInId(transid:String): FloatIn{
        return dao.searchFloatInId(transid)
    }

    suspend fun searchFloatInId2(wakalaid:String): FloatIn{
        return dao.searchFloatInId2(wakalaid)
    }

    suspend fun searchFloatInWakalaId(wakalaid:String): FloatInWakala{
        return dao.searchFloatInWakalaId(wakalaid)
    }

    //BALANCE
    val balance= dao.balance()

    suspend fun insertBalance(balance: Balance){
        dao.insertBalance(balance)
    }

    suspend fun insertTestBalance(balance: List<Balance>){
        dao.insertTestBalance(balance)
    }

    suspend fun getBalance():Balance{
        return dao.getBalance()
    }

    //FLOATOUT
    val floatOut=dao.floatOut()

    fun floatOutFilter(status: Int): LiveData<List<FloatOut>> {
        return dao.floatOutFilter(status)
    }

    fun floatOutFilter2(status: Int,modifiedat: Int): LiveData<List<FloatOut>> {
        return dao.floatOutFilter2(status,modifiedat)
    }

//    fun floatInFilter2(status: Int,modifiedat: Int): LiveData<List<FloatIn>> {
//        return dao.floatInFilter2(status,modifiedat)
//    }


    suspend fun insertFloatOut(floatout: FloatOut){
        return dao.insertFloatOut(floatout)
    }



    suspend fun insertFloatOutTest(floatout: List<FloatOut>){
        dao.insertFloatOutTest(floatout)
    }

    suspend fun updateFloatOut(status: Int, amount: String, wakalaidkey: String, floatinid:String, comment: String,modifiedat: Long) {
        return dao.updateFloatOut(status,amount,wakalaidkey, floatinid,comment,modifiedat)
    }

    suspend fun updateFloatOut2(status: Int, amount: String, floatinid:String, comment: String,modifiedat:Long) {
        return dao.updateFloatOut2(status,amount,floatinid,comment,modifiedat)
    }

    suspend fun searchFloatOutId(transid:String): FloatOut{
        return dao.searchFloatOutId(transid)
    }

    suspend fun searchFloatOutId2(wakalaname: String): FloatOut{
        return dao.searchFloatOutId2(wakalaname)
    }

    suspend fun searchFloatOutId3(floatinid: String): FloatOut{
        return dao.searchFloatOutId3(floatinid)
    }
    //WAKALAMKUU
    val wakalaMkuu=dao.WakalaMkuu()


    suspend fun insertWakalaMkuu(wakalaMkuu: List<WakalaMkuu>){
        dao.insertWakalaMkuu(wakalaMkuu)
    }
//    @Query("SELECT * FROM wakalamkuu_table WHERE tigopesa = :columnvalue AND status = 1 LIMIT 1")
//    suspend fun searchWakalaMkuuTigo( columnvalue:String):WakalaMkuu

    suspend fun searchWakalaMkuu(column:String, columnvalue:String): WakalaMkuu{
        return dao.searchWakalaMkuu(column, columnvalue)
    }

    suspend fun searchWakalaMkuuTigo(columnvalue:String): WakalaMkuu{
        return dao.searchWakalaMkuuTigo(columnvalue)
    }
    suspend fun searchWakalaMkuuTtcl(columnvalue:String): WakalaMkuu{
        return dao.searchWakalaMkuuTtcl(columnvalue)
    }

    suspend fun searchWakalaMkuuVoda(columnvalue:String): WakalaMkuu{
        return dao.searchWakalaMkuuVoda(columnvalue)
    }

    suspend fun searchWakalaMkuuHalotel(columnvalue:String): WakalaMkuu{
        return dao.searchWakalaMkuuHalotel(columnvalue)
    }

    suspend fun searchWakalaMkuuAirtel(columnvalue:String): WakalaMkuu{
        return dao.searchWakalaMkuuAirtel(columnvalue)
    }

    suspend fun getWakalaMkuu(): WakalaMkuu{
        return dao.getWakalaMkuu()
    }

    //WAKALA
    val wakala=dao.Wakala()

    val getWakalaCount=dao.getWakalaCount()

    suspend fun insertWakala(wakala: List<Wakala>){
        dao.insertWakala(wakala)
    }

    suspend fun searchWakala(columnvalue:String): Wakala{
        return dao.searchWakala(columnvalue)
    }

    suspend fun searchWakalaContact(columnvalue:String): Wakala{
        return dao.searchWakalaContact(columnvalue)
    }
    suspend fun searchWakalaTigo(columnvalue:String): Wakala{
        return dao.searchWakalaTigo(columnvalue)
    }
    suspend fun searchWakalaVoda(columnvalue:String): Wakala{
        return dao.searchWakalaVoda(columnvalue)
    }
    suspend fun searchWakalaAirtel(columnvalue:String): Wakala{
        return dao.searchWakalaAirtel(columnvalue)
    }

    suspend fun searchWakalaTtcl(columnvalue:String): Wakala{
        return dao.searchWakalaTtcl(columnvalue)
    }
    suspend fun searchWakalaHalotel(columnvalue:String): Wakala{
        return dao.searchWakalaHalotel(columnvalue)
    }
    suspend fun updateWakala(tigopesa: String,  wakalaid : String):Int  {
        return dao.updateWakala(tigopesa,  wakalaid)
    }

    //MAXAMOUNT
    val maxAmount= dao.maxAmount()

    suspend fun insertMaxAmount(maxAmount: MaxAmount){
        dao.insertMaxAmount(maxAmount)
    }

    suspend fun getMaxAmount():MaxAmount{
        return dao.getMaxAmount()
    }

    //balance

}