package com.example.airtelmanewakala.viewmodel

import androidx.databinding.Bindable
import androidx.databinding.Observable
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.db.MaxAmount
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MaxAmountViewModel(private val repository: MobileRepository): ViewModel(), Observable {
      val maxAmount=repository.maxAmount
    val balance= repository.balance

    @Bindable
    val amountButton= MutableLiveData<String>()
    @Bindable
    val checkButton= MutableLiveData<String>()

    @Bindable
    val inputamount = MutableLiveData<String>()
//
    init {
        amountButton.value= "Save"
    checkButton.value="ALLOW AUTOMATION"

    }

//   private val sharedPref: SharedPreferences = getApplication<this>().getSharedPreferences("myPref", Context.MODE_PRIVATE)
    @Bindable
    val saveOrUpdateButtonText =MutableLiveData<String>()

    init {
        saveOrUpdateButtonText.value= "Save"
    }

fun saveAmount(){
    if (inputamount.value!=null){
        val amount=inputamount.value!!
        val createdAt = System.currentTimeMillis()
        insert(MaxAmount(0 ,amount, createdAt))
    }
    inputamount.value=null

}

    fun insert(maxAmount: MaxAmount): Job =
        viewModelScope.launch {
            repository.insertMaxAmount(maxAmount)
     }

    override fun addOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }

    override fun removeOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }
}