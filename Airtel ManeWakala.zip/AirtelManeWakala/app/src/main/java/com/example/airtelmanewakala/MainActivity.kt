package com.example.airtelmanewakala

//import android.databinding.DataBindingUtil
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.viewpager2.widget.ViewPager2
import com.example.airtelmanewakala.Adapter.ViewPageAdapter
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
//    private lateinit var binding: ActivityMainBinding
//    private lateinit var wakalaMkuuViewModel: WakalaMkuuViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        binding= DataBindingUtil.setContentView(this,R.layout.activity_main)
//        val dao =MoblieDatabase.getInstance(application).MobileDAO
//        val repository = MobileRepository(dao)
////        val factory =WakalaMkuuViewModelFactory(repository

    setContentView(R.layout.activity_main)

        val tabLayout=findViewById<TabLayout>(R.id.tab_layout)
        val viewPager2=findViewById<ViewPager2>(R.id.view_pager_2).apply {
            isUserInputEnabled=false
        }

        val adapter= ViewPageAdapter(supportFragmentManager,lifecycle)

//        <uses-permission android:name="android.permission.CALL_PHONE" />
//        <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
//        <uses-permission android:name="android.permission.RECEIVE_SMS"/>
//        <uses-permission android:name="android.permission.READ_SMS" />
//        <uses-permission android:name="android.permission.SEND_SMS"/>
//        <uses-permission android:name="android.permission.ACTION_MANAGE_OVERLAY_PERMISSION" />
//        <uses-permission android:name="android.permission.READ_PHONE_STATE" />
//        <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
//        <uses-permission android:name="android.permission.INTERNET"/>

        if(ActivityCompat.checkSelfPermission(this, arrayOf(
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SYSTEM_ALERT_WINDOW,
                Manifest.permission.READ_SMS,
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION
            ).toString()
            )!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.RECEIVE_SMS,
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Manifest.permission.SYSTEM_ALERT_WINDOW,
                Manifest.permission.SEND_SMS,Manifest.permission.READ_PHONE_STATE,Manifest.permission.CALL_PHONE)
                ,111)
        }

        viewPager2.adapter=adapter
        TabLayoutMediator(tabLayout,viewPager2){tab,position->
            when(position){
                0->{
                    tab.text="Wak"
                }
                1->{
                    tab.text="W/M"
                }
                2->{
                    tab.text="F/0"
                }
                3->{
                    tab.text="F/I"
                }
                4->{
                    tab.text="Bal"
                }
//                5->{
//                    tab.text="B"
//                }
            }

        }.attach()
    }
}