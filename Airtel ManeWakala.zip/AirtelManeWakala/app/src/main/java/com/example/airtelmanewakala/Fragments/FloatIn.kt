package com.example.airtelmanewakala.Fragments

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airtelmanewakala.RecyclerView.RecyclerViewFloatIn
import com.example.airtelmanewakala.databinding.FragmentFloatInBinding
import com.example.airtelmanewakala.db.MoblieDatabase
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.db.FloatIn
import com.example.airtelmanewakala.viewmodel.FloatInViewModel
import com.example.airtelmanewakala.viewmodel.FloatInViewModelFactory
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class FloatIn : Fragment() {
    private lateinit var binding: FragmentFloatInBinding
    private lateinit var floatInViewModel: FloatInViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //binding= FragmentWakalaBinding.inflate(inflater, container, false)

        binding= FragmentFloatInBinding.inflate(inflater,container,false)
//       binding =DataBindingUtil.inflate(inflater,R.layout.fragment_wakala_mkuu, container, false)
        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
        val repository = dao?.let { MobileRepository(it) }
        val factory = repository?.let { FloatInViewModelFactory(it) }
        floatInViewModel= factory?.let { ViewModelProvider(this, it).get(FloatInViewModel::class.java) }!!
        binding.myFloatInViewModel=floatInViewModel
        binding.lifecycleOwner=this
        initRecyclerView()
        val all = binding.allbutton
        val zero = binding.zerobutton
        val one = binding.onebutton
        val two = binding.twobutton
        val three = binding.threebutton

        all.setOnClickListener() {
            val sharedPref= context!!.getSharedPreferences("myPref", Context.MODE_PRIVATE)
            val cheki=sharedPref.getBoolean("cheki",false)
            Toast.makeText(activity, cheki.toString(), Toast.LENGTH_SHORT).show()
            binding.floatinRecyclerView.layoutManager= LinearLayoutManager(context)
            floatInViewModel.floatIn.observe(this, Observer {
                binding.floatinRecyclerView.adapter= RecyclerViewFloatIn(it,{selectedItem: FloatIn ->listItemClicked(selectedItem)})

            })
        }
        zero.setOnClickListener() {
            Toast.makeText(activity, "Waiting Order", Toast.LENGTH_SHORT).show()
            binding.floatinRecyclerView.layoutManager= LinearLayoutManager(context)
            floatInViewModel.floatInFilterZero.observe(this, Observer {
                binding.floatinRecyclerView.adapter= RecyclerViewFloatIn(it,{selectedItem: FloatIn ->sendTextWakala(selectedItem)})
            })
        }
        one.setOnClickListener() {
            Toast.makeText(activity, "Sent order", Toast.LENGTH_SHORT).show()
            binding.floatinRecyclerView.layoutManager= LinearLayoutManager(context)
            floatInViewModel.floatInFilterOne.observe(this, Observer {
                binding.floatinRecyclerView.adapter= RecyclerViewFloatIn(it,{selectedItem: FloatIn ->sendTextWakalaMkuu(selectedItem)})
            })
        }
        two.setOnClickListener() {
            Toast.makeText(activity, "amount to large", Toast.LENGTH_SHORT).show()
            binding.floatinRecyclerView.layoutManager= LinearLayoutManager(context)
            floatInViewModel.floatInFilterTwo.observe(this, Observer {
                binding.floatinRecyclerView.adapter= RecyclerViewFloatIn(it,{selectedItem: FloatIn ->sendTextWakala(selectedItem)})
            })
        }
        three.setOnClickListener() {
//            Toast.makeText(activity, "not our wakala", Toast.LENGTH_SHORT).show()ef
            val createdAt = System.currentTimeMillis()
            val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            val instant = Instant.ofEpochMilli(createdAt )
            val date = LocalDateTime.ofInstant(instant, ZoneId.systemDefault())
            val yes=formatter.format(date)
//        wakalaViewModel.updatewakala("0766666666",wakala.wakalaid)
            Log.i("TAGi2", "$yes")
            Toast.makeText(activity, " ${yes}", Toast.LENGTH_SHORT).show()
            binding.floatinRecyclerView.layoutManager= LinearLayoutManager(context)
            floatInViewModel.floatInFilterThree.observe(this, Observer {
                binding.floatinRecyclerView.adapter= RecyclerViewFloatIn(it,{selectedItem: FloatIn ->listItemClicked(selectedItem)})
            })
        }
        return  binding.root
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_wakala_mkuu, container, false)

    }


    fun initRecyclerView(){
//        binding.transactionRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.floatinRecyclerView.layoutManager= LinearLayoutManager(context)
        displayTransactionList()
    }

    private fun displayTransactionList(){
        floatInViewModel.floatIn.observe(this, Observer {
            Log.i("FLOATIN",it.toString())
            binding.floatinRecyclerView.adapter= RecyclerViewFloatIn(it,{selectedItem: FloatIn ->listItemClicked(selectedItem)})
        })

    }
    private fun listItemClicked(floatIn: FloatIn){
//floatOutViewModel.

//        wakalaViewModel.updatewakala("0766666666",wakala.wakalaid)
        Toast.makeText(activity, "cheki.toString()", Toast.LENGTH_SHORT).show()
    }

    private fun sendTextWakalaMkuu(floatIn: FloatIn){
        val sms = SmsManager.getDefault()
        var sendSms = "WAKALA MKUU ${floatIn.wakalaorder} ${floatIn.amount} ${floatIn.wakalacode} ${floatIn.wakalaname} ${floatIn.floatinid}"
        sms.sendTextMessage(floatIn.wakalamkuunumber, null, sendSms, null, null)
//        Toast.makeText(activity, "USSD ${floatIn.amount}", Toast.LENGTH_SHORT).show()
    }
    private fun sendTextWakala(floatIn: FloatIn){
        val sms = SmsManager.getDefault()
        var sendSms = "${floatIn.amount} ${floatIn.transid} ya AIRTEL itumwe wapi?"
//      val sendSms2: ArrayList<String> = sms.divideMessage(sendSms)
        sms.sendTextMessage(
            floatIn.wakalanumber,
            null,
            sendSms,
            null,
            null
        )
        Toast.makeText(activity, "USSD ${floatIn.amount}", Toast.LENGTH_SHORT).show()
    }
}