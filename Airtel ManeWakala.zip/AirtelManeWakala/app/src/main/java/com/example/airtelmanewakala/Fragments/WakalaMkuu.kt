package com.example.airtelmanewakala.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airtelmanewakala.RecyclerView.RecyclerViewWakalaMkuu
import com.example.airtelmanewakala.databinding.FragmentWakalaMkuuBinding
import com.example.airtelmanewakala.db.MoblieDatabase
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.db.WakalaMkuu
import com.example.airtelmanewakala.viewmodel.WakalaMkuuViewModel
import com.example.airtelmanewakala.viewmodel.WakalaMkuuViewModelFactory

class WakalaMkuu : Fragment() {
    private lateinit var binding: FragmentWakalaMkuuBinding
    private lateinit var wakalaMkuuViewModel: WakalaMkuuViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        val dao = MoblieDatabase.getInstance(requireContext() as Application).MobileDAO
//        val repository = MobileRepository(dao)
//        val factory = WakalaMkuuViewModelFactory(repository)
//        wakalaMkuuViewModel= ViewModelProvider(this,factory).get(WakalaMkuuViewModel::class.java)
//

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

      binding= FragmentWakalaMkuuBinding.inflate(inflater, container, false)
//       binding =DataBindingUtil.inflate(inflater,R.layout.fragment_wakala_mkuu, container, false)
        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
        val repository = dao?.let { MobileRepository(it) }
        val factory = repository?.let { WakalaMkuuViewModelFactory(it, activity!!.application) }
        wakalaMkuuViewModel= factory?.let { ViewModelProvider(this, it).get(WakalaMkuuViewModel::class.java) }!!
        binding.myWakalaMkuuViewModel=wakalaMkuuViewModel
        binding.lifecycleOwner=this
      initRecyclerView()
//        val buttonCalculate = binding.getButton
//
//        buttonCalculate.setOnClickListener() {
//            Toast.makeText(activity, "Hola ratita", Toast.LENGTH_SHORT).show()
//        }
        return  binding.root
        // Inflate the layout for this fragment
         //return inflater.inflate(R.layout.fragment_wakala_mkuu, container, false)
    }


    fun initRecyclerView(){
//        binding.transactionRecyclerView.layoutManager= LinearLayoutManager(this)
       binding.wakalamkuuRecyclerView.layoutManager=LinearLayoutManager(context)
        displayTransactionList()
    }
//
    private fun displayTransactionList(){
    wakalaMkuuViewModel.wakalaMkuu.observe(this, Observer {
        Log.i("MYWAKALAMKUU",it.toString())
        binding.wakalamkuuRecyclerView.adapter=RecyclerViewWakalaMkuu(it,{selectedItem:WakalaMkuu->listItemClicked(selectedItem)})
    })
//        transactionViewModal.transaction.observe(this, Observer {
//            Log.i("MYTAG",it.toString())
//
//        })
    }

    private fun listItemClicked(wakalaMkuu: WakalaMkuu){
        Toast.makeText(activity, "Hola ratita ${wakalaMkuu.wakalamkuuid}", Toast.LENGTH_SHORT).show()

    }
}