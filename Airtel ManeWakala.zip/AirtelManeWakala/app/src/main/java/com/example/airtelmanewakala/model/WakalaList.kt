package com.example.airtelmanewakala.model

data class WakalaList(val tigoname:String?,val tigopesa:String?,val tigophone:String?,
val vodaname:String?,val mpesa:String?,val vodaphone:String?,val halophone:String?,val haloname:String?,val halopesa:String?,
    val airtelname:String?,val airtelmoney:String?,val airtelphone: String?,val ttclname:String?,val ttclphone:String?,val tpesa :String?,val contact :String?,val maxamount :String?)