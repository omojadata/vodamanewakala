package com.example.airtelmanewakala.db

import androidx.lifecycle.LiveData
import androidx.room.*


@Dao
interface MobileDAO {

    //FLOATIN
    @Query("SELECT * FROM floatin_table")
    fun floatIn():LiveData<List<FloatIn>>

    @Query("SELECT * FROM floatin_table WHERE status = :status")
    fun floatInFilter(status: Int):LiveData<List<FloatIn>>

    @Insert
    suspend fun insertFloatIn(FloatIn: FloatIn)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFloatInTest(FloatIn: List<FloatIn>)

    @Query("UPDATE floatin_table SET status = :status,wakalaorder=:wakalaorder,comment=:comment,wakalacode=:wakalacode, wakalamkuunumber=:wakalamkuunumber,wakalaname=:wakalaname ,modifiedat=:modifiedat WHERE floatinid=:floatinid AND status=0")
    suspend fun updateFloatIn(status: Int, floatinid: Int, wakalaorder:String,comment: String, wakalacode:String,wakalamkuunumber:String,wakalaname:String,modifiedat:Long):Int

    @Query("SELECT * FROM floatin_table WHERE transid = :transid LIMIT 1")
    suspend fun searchFloatInId(transid: String):FloatIn

    @Query("SELECT * FROM floatin_table WHERE wakalaidkey=:wakalaid AND status=0 LIMIT 1")
    suspend fun searchFloatInId2(wakalaid: String):FloatIn

    @Query("SELECT * FROM floatin_table LEFT JOIN wakala_table ON floatin_table.wakalaidkey=wakala_table.wakalaid WHERE floatin_table.wakalaidkey = :wakalaid AND floatin_table.status=0 LIMIT 1")
    suspend fun searchFloatInWakalaId(wakalaid: String):FloatInWakala

    @Insert
    suspend fun checkFloatInExists(FloatIn: List<FloatIn>)

    //BALANCE
    @Query("SELECT * FROM balance_table ORDER BY createdAt DESC")
    fun balance():LiveData<List<Balance>>

    @Insert
    suspend fun insertBalance(balance: Balance)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTestBalance(balance: List<Balance>)

    @Query("SELECT * FROM balance_table WHERE  status = 1 ORDER BY createdAt DESC LIMIT 1")
    suspend fun getBalance():Balance


    //FLOATOUT
    @Query("SELECT * FROM floatout_table")
    fun floatOut():LiveData<List<FloatOut>>

    @Query("SELECT * FROM floatout_table WHERE status = :status LIMIT 1")
    fun floatOutFilter(status: Int):LiveData<List<FloatOut>>

   @Query("SELECT * FROM floatout_table WHERE status = :status AND modifiedat>= :modifiedat LIMIT 1")
   fun floatOutFilter2(status: Int,modifiedat: Int):LiveData<List<FloatOut>>

    @Insert
    suspend fun insertFloatOut(FloatOut:FloatOut)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFloatOutTest(FloatOut: List<FloatOut>)

    @Query("UPDATE floatout_table SET status = :status, floatinid=:floatinid, comment=:comment,modifiedat=:modifiedat WHERE amount =:amount AND wakalaidkey=:wakalaidkey")
    suspend fun updateFloatOut(status: Int, amount: String, wakalaidkey: String, floatinid:String, comment: String,modifiedat:Long)

     @Query("UPDATE floatout_table SET status = :status ,comment=:comment,modifiedat=:modifiedat  WHERE amount =:amount AND floatinid=:floatinid ")
     suspend fun updateFloatOut2(status: Int, amount: String,  floatinid:String,comment: String, modifiedat: Long)

    @Query("SELECT * FROM floatout_table WHERE transid = :transid LIMIT 1")
    suspend fun searchFloatOutId(transid: String):FloatOut

    @Query("SELECT * FROM floatout_table WHERE wakalaname = :wakalaname AND status=0 LIMIT 1")
    suspend fun searchFloatOutId2(wakalaname: String):FloatOut

    @Query("SELECT * FROM floatout_table WHERE floatinid = :floatinid AND status=0 LIMIT 1")
    suspend fun searchFloatOutId3(floatinid: String):FloatOut
//    @Insert
//    suspend fun insertFloatOut(FloatOut: FloatOut):Int

     //WAKALAMKUU
    @Query("SELECT * FROM wakalamkuu_table ORDER BY wakalamkuuid DESC LIMIT 1")
    fun WakalaMkuu():LiveData<List<WakalaMkuu>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWakalaMkuu(wakalaMkuu: List<WakalaMkuu>)


    @Query("SELECT * FROM wakalamkuu_table WHERE  status = 1 LIMIT 1")
    suspend fun getWakalaMkuu():WakalaMkuu

    @Query("SELECT * FROM wakalamkuu_table WHERE :column = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaMkuu(column:String, columnvalue:String):WakalaMkuu

 @Query("SELECT * FROM wakalamkuu_table WHERE tigopesa = :columnvalue AND status = 1 LIMIT 1")
 suspend fun searchWakalaMkuuTigo( columnvalue:String):WakalaMkuu

 @Query("SELECT * FROM wakalamkuu_table WHERE mpesa = :columnvalue AND status = 1 LIMIT 1")
 suspend fun searchWakalaMkuuVoda( columnvalue:String):WakalaMkuu

 @Query("SELECT * FROM wakalamkuu_table WHERE airtelmoney = :columnvalue AND status = 1 LIMIT 1")
 suspend fun searchWakalaMkuuAirtel(columnvalue:String):WakalaMkuu

 @Query("SELECT * FROM wakalamkuu_table WHERE halopesa = :columnvalue AND status = 1 LIMIT 1")
 suspend fun searchWakalaMkuuHalotel( columnvalue:String):WakalaMkuu

    @Query("SELECT * FROM wakalamkuu_table WHERE tpesa = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaMkuuTtcl( columnvalue:String):WakalaMkuu

    @Update
    suspend fun updateWakalaMkuu(wakalaMkuu: WakalaMkuu)


    //Wakala
    @Query("SELECT * FROM wakala_table")
    fun Wakala():LiveData<List<Wakala>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWakala(wakala: List<Wakala>)

    @Query("SELECT COUNT (airtelmoney) FROM wakala_table WHERE status = 1")
  fun getWakalaCount():LiveData<Int>

    @Query("SELECT * FROM wakala_table WHERE airtelname = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakala( columnvalue:String):Wakala

    @Query("SELECT * FROM wakala_table WHERE contact = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaContact( columnvalue:String):Wakala

    @Query("SELECT * FROM wakala_table WHERE tigopesa = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaTigo( columnvalue:String):Wakala

    @Query("SELECT * FROM wakala_table WHERE airtelmoney = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaAirtel( columnvalue:String):Wakala

    @Query("SELECT * FROM wakala_table WHERE mpesa = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaVoda( columnvalue:String):Wakala

    @Query("SELECT * FROM wakala_table WHERE halopesa = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaHalotel( columnvalue:String):Wakala

    @Query("SELECT * FROM wakala_table WHERE tpesa = :columnvalue AND status = 1 LIMIT 1")
    suspend fun searchWakalaTtcl( columnvalue:String):Wakala

    @Query("UPDATE wakala_table SET tigopesa = :tigopesa WHERE wakalaid =:wakalaid")
    suspend fun updateWakala(tigopesa: String,  wakalaid : String):Int

    //Max ACCOUNT

    @Insert
    suspend fun insertMaxAmount(maxAmount: MaxAmount)

    @Query("SELECT * FROM maxamount_table ORDER BY maxamountid DESC LIMIT 1")
    fun maxAmount():LiveData<List<MaxAmount>>

 @Query("SELECT * FROM maxamount_table ORDER BY maxamountid DESC LIMIT 1")
 suspend fun getMaxAmount():MaxAmount

   //balance


////AIRTELMONEY
////Out
// Umetuma Tshs5,000,000.00 kwa 678909076 AMINA NASORRO ANTONY. Salio Tshs2,540,890.00.Muamala No.PP2104011625.E91936.Tuma Pesa BURE na Airtel APP
////IN
// Umepokea Tshs2,000,000.00 kutoka 788014470,ASANITIELI RAPHAEL MKENDA. Salio jipya Tshs7,053,935.00.Muamala No:PP210401.1601.B46963
//
//
////HALOPESA
// Utambulisho wa muamala:658767567.WAKALA:Susan M Mbwagai,namba ya simu 255623641076 imetoa TSH 150,000 wakati 01/04/2021 14:54:38. Kamisheni: TSH 0.Salio jipya la floti ni TSH3,164,634. Asante!
//
// Utambulisho wa muamala:658684058.TSH 100,000 imewekwa kwa WAKALA:Suzan M Mbwagai,utambulisho 334833 wakati 01/04/2021 13:20:18. Kamisheni: TSH 0.Salio jipya la floti ni TSH 2,714,634. Ahsante!
//
////VODACOM
// 8D1750EA8L9 imethibitishwa 1/4/21 saa 4:48 PM chukua Tsh3,000,000.00 toka 950506 - ESTER SHOGHOLO MSOFE. Salio jipya ya akaunti yako ni Tsh7,128,782.00
//
// 8D1450EF2L2 Imethibitishwa,tarehe 1/4/21 saa 5:05 PM chukua Tsh700,000.00 kutoka 555062 - j link Christopher Nkuu.Salio lako la M-Pesa ni Tsh7,828,792.00
//
////TIGOPESA
// Zoezi la kuhamisha Fedha kutokaa kwa TRACE MOBILE LIMITED kwenda kwa TRACE MGT TILL GO

}