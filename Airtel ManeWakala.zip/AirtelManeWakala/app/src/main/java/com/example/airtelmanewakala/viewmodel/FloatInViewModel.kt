package com.example.airtelmanewakala.viewmodel

import android.util.Log
import androidx.databinding.Bindable
import androidx.databinding.Observable
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.airtelmanewakala.db.FloatIn
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.network.RetroInstance
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FloatInViewModel(private val repository: MobileRepository): ViewModel(), Observable {


    val floatIn:LiveData<List<FloatIn>> =repository.floatIn
    val floatInFilterZero:LiveData<List<FloatIn>> =repository.floatInFilter(0)
    val floatInFilterOne:LiveData<List<FloatIn>> = repository.floatInFilter(1)
    val floatInFilterTwo:LiveData<List<FloatIn>> = repository.floatInFilter(2)
    val floatInFilterThree:LiveData<List<FloatIn>> = repository.floatInFilter(3)

    @Bindable
    val allButton = MutableLiveData<String>()
    val zeroButton = MutableLiveData<String>()
    val oneButton = MutableLiveData<String>()
    val twoButton = MutableLiveData<String>()
    val threeButton = MutableLiveData<String>()
    val uploadButton = MutableLiveData<String>()

    init {
        allButton.value= "All"
    }
    init {
        zeroButton.value= "Pnd"
    }
    init {
        oneButton.value= "Dne"
    }
    init {
        twoButton.value= "Lrg"
    }
    init {
        threeButton.value= "N/O"
    }
    init {
        uploadButton.value= "UPL"
    }
    @Bindable
    val getButtonText=MutableLiveData<String>()

    init {
        getButtonText.value= "FETCH FLOATIN"
    }


    fun insert(floatin: List<FloatIn>): Job =
        viewModelScope.launch {
            repository.insertFloatInTest(floatin)
        }

    fun onGetButton() {
        val service= RetroInstance.getRetroInstance()
        val retrofitData = service?.getDataFloatIn()

        if (retrofitData != null) {
            retrofitData.enqueue(object : Callback<List<FloatIn>> {
                override fun onResponse(
                    call: Call<List<FloatIn>>,
                    response: Response<List<FloatIn>>
                ) {
                    val responseBody =response.body()
                    if (responseBody != null) {
                        insert(responseBody)
                    }

                    Log.d("WAKALAmy", "oKEY")
                }

                override fun onFailure(call: Call<List<FloatIn>>, t: Throwable) {
                    TODO("Not yet implemented")
                }
            })
        }
        else{
            Log.d("WAKALA", "omNull")
        }
    }

    override fun addOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }

    override fun removeOnPropertyChangedCallback(callback: Observable.OnPropertyChangedCallback?) {

    }
}