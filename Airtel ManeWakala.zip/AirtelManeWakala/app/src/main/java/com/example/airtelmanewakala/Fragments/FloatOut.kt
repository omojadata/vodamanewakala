package com.example.airtelmanewakala.Fragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airtelmanewakala.RecyclerView.RecyclerViewFloatOut
import com.example.airtelmanewakala.databinding.FragmentFloatOutBinding
import com.example.airtelmanewakala.db.MoblieDatabase
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.db.FloatOut
import com.example.airtelmanewakala.viewmodel.FloatOutViewModel
import com.example.airtelmanewakala.viewmodel.FloatOutViewModelFactory
import com.romellfudi.ussdlibrary.USSDApi
import com.romellfudi.ussdlibrary.USSDController
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.collections.HashMap
import kotlin.collections.HashSet


class FloatOut : Fragment() {
    private lateinit var binding: FragmentFloatOutBinding
    private lateinit var floatOutViewModel: FloatOutViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //binding= FragmentWakalaBinding.inflate(inflater, container, false)

        binding= FragmentFloatOutBinding.inflate(inflater,container,false)
//       binding =DataBindingUtil.inflate(inflater,R.layout.fragment_wakala_mkuu, container, false)
        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
        val repository = dao?.let { MobileRepository(it) }
        val factory = repository?.let { FloatOutViewModelFactory(it) }
        floatOutViewModel= factory?.let { ViewModelProvider(this, it).get(FloatOutViewModel::class.java) }!!
        binding.myFloatOutViewModel=floatOutViewModel
        binding.lifecycleOwner=this
        initRecyclerView()
        val all = binding.allbutton
        val zero = binding.zerobutton
        val one = binding.onebutton
        val two = binding.twobutton
        val three = binding.threebutton
        all.setOnClickListener() {
            Toast.makeText(activity, "All", Toast.LENGTH_SHORT).show()
            binding.floatoutRecyclerView.layoutManager= LinearLayoutManager(context)
            floatOutViewModel.floatOut.observe(this, Observer {
                binding.floatoutRecyclerView.adapter= RecyclerViewFloatOut(it) { selectedItem: FloatOut ->
                    listItemClicked(
                        selectedItem
                    )
                }
            })
        }
        zero.setOnClickListener() {
            Toast.makeText(activity, "Waiting Ussd", Toast.LENGTH_SHORT).show()
            binding.floatoutRecyclerView.layoutManager= LinearLayoutManager(context)
            floatOutViewModel.floatOutFilterZero.observe(this, Observer {
                binding.floatoutRecyclerView.adapter= RecyclerViewFloatOut(it) { selectedItem: FloatOut ->
                    sendUSSD(selectedItem)
                }
            })
        }
        one.setOnClickListener() {
            Toast.makeText(activity, "Waiting Response", Toast.LENGTH_SHORT).show()
            binding.floatoutRecyclerView.layoutManager= LinearLayoutManager(context)
            floatOutViewModel.floatOutFilterOne.observe(this, Observer {
                binding.floatoutRecyclerView.adapter= RecyclerViewFloatOut(it) { selectedItem: FloatOut ->
                    listItemClicked(
                        selectedItem
                    )
                }
            })
        }
        two.setOnClickListener() {
            Toast.makeText(activity, "DONE", Toast.LENGTH_SHORT).show()
            binding.floatoutRecyclerView.layoutManager= LinearLayoutManager(context)
            floatOutViewModel.floatOutFilterTwo.observe(this, Observer {
                binding.floatoutRecyclerView.adapter= RecyclerViewFloatOut(it) { selectedItem: FloatOut ->
                    listItemClicked(
                        selectedItem
                    )
                }
            })
        }

        three.setOnClickListener() {
            Toast.makeText(activity, "not our wakala", Toast.LENGTH_SHORT).show()
            binding.floatoutRecyclerView.layoutManager= LinearLayoutManager(context)
            floatOutViewModel.floatOutFilterThree.observe(this, Observer {
                binding.floatoutRecyclerView.adapter= RecyclerViewFloatOut(it) { selectedItem: FloatOut ->
                    listItemClicked(
                        selectedItem
                    )
                }
            })
        }
        return  binding.root
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_wakala_mkuu, container, false)

    }


    private fun initRecyclerView(){
//        binding.transactionRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.floatoutRecyclerView.layoutManager= LinearLayoutManager(context)
        displayTransactionList()
    }

    private fun displayTransactionList(){
        floatOutViewModel.floatOut.observe(this, Observer {
            Log.i("FLOATIN",it.toString())
            binding.floatoutRecyclerView.adapter= RecyclerViewFloatOut(it) { selectedItem: FloatOut ->
                listItemClicked(
                    selectedItem
                )
            }
        })

    }

    private fun listItemClicked(floatOut: FloatOut){
//floatOutViewModel.
//        wakalaViewModel.updatewakala("0766666666",wakala.wakalaid)
        Toast.makeText(activity, "Hola ratita ${floatOut.amount}", Toast.LENGTH_SHORT).show()
    }

    private fun sendUSSD(floatOut: FloatOut){
        val sharedPref= context!!.getSharedPreferences("myPref",Context.MODE_PRIVATE)
//        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
//        val repository = dao?.let { MobileRepository(it) }
        val checkBalance= sharedPref.getInt("balance",0)
        if(checkBalance!! >=floatOut.amount.toInt() )
        {
            USSDaction("*150*60#",floatOut.wakalacode,floatOut.amount,floatOut.floatinid)
        }else{
            Toast.makeText(activity, "NO BALANCE/ HAMNA SALIO", Toast.LENGTH_SHORT).show()

        }
//floatOutViewModel.
//        wakalaViewModel.updatewakala("0766666666",wakala.wakalaid)
        Toast.makeText(activity, "Hola ratita ${floatOut.amount}", Toast.LENGTH_SHORT).show()
    }
   private fun USSDaction(ussdCode: String,wakalano:String,amount:String,floatinid:String) {
        val map = HashMap<String, HashSet<String>>()
       val modifiedAt = System.currentTimeMillis()
        map["KEY_LOGIN"] = HashSet(listOf("USSD code running..."))
        map["KEY_ERROR"] = HashSet(listOf("problema", "problem", "error", "null"))
        val ussdApi: USSDApi? = context?.let { USSDController.getInstance(it) }
        ussdApi?.callUSSDOverlayInvoke(ussdCode, map!!, object : USSDController.CallbackInvoke {
            override fun responseInvoke(message: String) {
                // message has the response string data
                ussdApi!!.send("1") { // it: response response
                    // second option list - select option 1
                    ussdApi.send("1") { // it: response message
                        ussdApi.send(wakalano) { // it: response message
                            ussdApi.send(amount) { // it: response message
                                GlobalScope.launch{
                                    val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
                                    dao?.let { MobileRepository(it) }?.updateFloatOut2(1,amount,floatinid,"Waiting Response", modifiedAt )
                                }

                                ussdApi.send("6499") { // it: response message

                                    Log.i(
                                        "TAJ",
                                        message
                                    )
                                }
                            }
                        }
                    }
                }
            }

            override fun over(message: String) {
                Log.i(
                    "TAJ",
                    message
                )
                // message has the response string data from USSD or error
                // response no have input text, NOT SEND ANY DATA
            }
        })
    }

}