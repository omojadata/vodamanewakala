package com.example.airtelmanewakala.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airtelmanewakala.RecyclerView.RecyclerViewBalance
import com.example.airtelmanewakala.databinding.FragmentBalanceBinding
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.db.MoblieDatabase
import com.example.airtelmanewakala.viewmodel.BalanceViewModel
import com.example.airtelmanewakala.viewmodel.BalanceViewModelFactory

class Balance: Fragment() {
      private lateinit var binding: FragmentBalanceBinding
      private  lateinit var balanceViewModel: BalanceViewModel
    //    private lateinit var wakalaMkuuViewModel: WakalaMkuuViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
//        binding= FragmentMaxamountBinding.inflate(inflater,container,false)
        binding= FragmentBalanceBinding.inflate(inflater,container,false)
        //binding= FragmentWakalaMkuuBinding.inflate(inflater, container, false)
//       binding =DataBindingUtil.inflate(inflater,R.layout.fragment_wakala_mkuu, container, false)
        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
        val repository = dao?.let { MobileRepository(it) }
        val factory = repository?.let { BalanceViewModelFactory(it) }
        balanceViewModel= factory?.let { ViewModelProvider(this, it).get(BalanceViewModel::class.java) }!!
        binding.myBalanceViewModel=balanceViewModel
        binding.lifecycleOwner=this
        initRecyclerView()
        return  binding.root
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_wakala_mkuu, container, false)
    }


    fun initRecyclerView(){
//        binding.transactionRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.balanceRecyclerView.layoutManager= LinearLayoutManager(context)
        displayTransactionList()
    }
    //
    private fun displayTransactionList(){
        balanceViewModel.balance.observe(this, Observer {
            Log.i("a",it.toString())
            binding.balanceRecyclerView.adapter=
                RecyclerViewBalance(it)
        })
    }

}