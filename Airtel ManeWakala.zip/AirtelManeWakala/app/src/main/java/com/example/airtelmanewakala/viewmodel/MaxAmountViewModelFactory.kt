package com.example.airtelmanewakala.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.airtelmanewakala.db.MobileRepository

 class MaxAmountViewModelFactory (private val repository: MobileRepository): ViewModelProvider.Factory {
     override fun <T : ViewModel?>create(modelClass: Class<T>):T{
         if(modelClass.isAssignableFrom(MaxAmountViewModel::class.java)){
             return  MaxAmountViewModel(repository,) as T
         }
         throw  IllegalArgumentException("Unknown View Model Class")
     }

}