package com.example.airtelmanewakala

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.preferencesKey
import androidx.datastore.preferences.createDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

class ModePreference(context: Context) {
    //1
    private val dataStore: DataStore<Preferences> = context.createDataStore(
        name = "mode_preference"
    )

    //2
    suspend fun saveAutoMode(isAutoMode: Boolean) {
        dataStore.edit { preferences ->
            preferences[AUTO_MODE_KEY] = isAutoMode
        }
    }

    //3
    val autoMode: Flow<Boolean> = dataStore.data
        .map { preferences ->
            val uiMode = preferences[AUTO_MODE_KEY] ?: false
            uiMode
        }

    //2
    suspend fun saveBalanceMode(isbalance: String) {
        dataStore.edit { preferences ->
            preferences[MY_BALANCE_KEY] = isbalance
        }
    }

    //3
    val balanceMode: Flow<String> = dataStore.data.catch {
        if (it is IOException) {
            emit(emptyPreferences())
        } else {
            throw it
        }
    }.map {
        it[MY_BALANCE_KEY] ?: "Not Found"
    }

    //4
    companion object {
        private val AUTO_MODE_KEY = preferencesKey<Boolean>("auto_mode")
        private val MY_BALANCE_KEY = preferencesKey<String>("my_balance")
    }

}