package com.example.airtelmanewakala.Fragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airtelmanewakala.RecyclerView.RecyclerViewMaxAmount
import com.example.airtelmanewakala.databinding.FragmentMaxamountBinding
import com.example.airtelmanewakala.db.MoblieDatabase
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.viewmodel.MaxAmountViewModel
import com.example.airtelmanewakala.viewmodel.MaxAmountViewModelFactory

class MaxAmount: Fragment() {
//  private lateinit var binding: FragmentWakalaMkuuBinding
    private  lateinit var  binding: FragmentMaxamountBinding
    private lateinit var  maxAmountViewModel: MaxAmountViewModel
//    private lateinit var wakalaMkuuViewModel: WakalaMkuuViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

//        val dao = MoblieDatabase.getInstance(requireContext() as Application).MobileDAO
//        val repository = MobileRepository(dao)
//        val factory = WakalaMkuuViewModelFactory(repository)
//        wakalaMkuuViewModel= ViewModelProvider(this,factory).get(WakalaMkuuViewModel::class.java)
//

    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding= FragmentMaxamountBinding.inflate(inflater,container,false)
            val sharedPref= context!!.getSharedPreferences("myPref", Context.MODE_PRIVATE)
            val cheki=sharedPref.getBoolean("cheki",false)
            val editor = sharedPref.edit()
           binding.checkBoxButton.isChecked=cheki
        binding.checkBoxButton.setOnCheckedChangeListener { buttonView, isChecked ->
            //            binding.checkBoxButton.setOnClickListener {
            if (isChecked ){
                editor.apply {
                    putBoolean("cheki",true)
//                    binding.checkBoxButton.isChecked= true
                    apply()
                }
                Log.i("axe","1 ${isChecked} and ${cheki}")
            }else if (!isChecked){

                editor.apply {
                    putBoolean("cheki",false)
//                    binding.checkBoxButton.isChecked= false
                    apply()
                }
                Log.i("axe","2 ${isChecked } and ${cheki}")
            }
        }

//            Log.i("axe","2 ${isChecked} ")

//            binding.checkBoxButton.setOnClickListener {
//            if (cheki===false){
//
//                editor.apply {
//                    putBoolean("cheki",true)
////                    binding.checkBoxButton.isChecked= true
//                    apply()
//                }
//                Log.i("axe","1 ${checkii} and ${cheki}")
//            }else if (cheki===true){
//
//                editor.apply {
//                    putBoolean("cheki",false)
////                    binding.checkBoxButton.isChecked= false
//                    apply()
//                }
//                Log.i("axe","2 ${checkii} and ${cheki}")
//            }
//        }
        //binding= FragmentWakalaMkuuBinding.inflate(inflater, container, false)
//       binding =DataBindingUtil.inflate(inflater,R.layout.fragment_wakala_mkuu, container, false)
        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
        val repository = dao?.let { MobileRepository(it) }
        val factory = repository?.let { MaxAmountViewModelFactory(it) }
        maxAmountViewModel= factory?.let { ViewModelProvider(this, it).get(MaxAmountViewModel::class.java) }!!
        binding.myMaxAmountViewModel=maxAmountViewModel
        binding.lifecycleOwner=this
        initRecyclerView()
        return  binding.root
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_wakala_mkuu, container, false)
    }


    fun initRecyclerView(){
//        binding.transactionRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.maxamountRecyclerView.layoutManager= LinearLayoutManager(context)
        displayTransactionList()
    }
    //
    private fun displayTransactionList(){
        maxAmountViewModel.maxAmount.observe(this, Observer {
            Log.i("a",it.toString())
            binding.maxamountRecyclerView.adapter=
                RecyclerViewMaxAmount(it)
        })
    }

}