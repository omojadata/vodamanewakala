package com.example.airtelmanewakala.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "maxamount_table")
data class MaxAmount(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name="maxamountid")
    val maxamountid: Int,
    @ColumnInfo(name="amount")
    val amount: String,
    @ColumnInfo(name="createdAt")
    val createdAt: Long,
)
