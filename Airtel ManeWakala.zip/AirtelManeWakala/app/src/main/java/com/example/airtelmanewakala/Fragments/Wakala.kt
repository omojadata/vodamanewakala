package com.example.airtelmanewakala.Fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airtelmanewakala.RecyclerView.RecyclerViewWakala
import com.example.airtelmanewakala.databinding.FragmentWakalaBinding
import com.example.airtelmanewakala.db.MoblieDatabase
import com.example.airtelmanewakala.db.MobileRepository
import com.example.airtelmanewakala.db.Wakala
import com.example.airtelmanewakala.viewmodel.WakalaViewModelFactory
import com.example.airtelmanewakala.viewmodel.WakalaViewModel

class Wakala : Fragment() {
    private lateinit var binding: FragmentWakalaBinding
    private lateinit var wakalaViewModel: WakalaViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        // Inflate the layout for this fragment
//        binding= FragmentWakalaBinding.inflate(inflater, container, false)
//
//        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
//        val repository = dao?.let { MobileRepository(it) }
//        val factory = repository?.let { WakalaViewModelFactory(it) }
//        wakalaViewModel= factory?.let { ViewModelProvider(this, it).get(WakalaViewModel::class.java) }!!
//        binding.myWakalaViewModel= wakalaViewModel
//        binding.lifecycleOwner=this
//        initRecyclerView()
////        getMydata()
//        return  binding.root
//
//    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding= FragmentWakalaBinding.inflate(inflater, container, false)
//       binding =DataBindingUtil.inflate(inflater,R.layout.fragment_wakala, container, false)
        val dao = context?.let { MoblieDatabase.getInstance(it).MobileDAO }
        val repository = dao?.let { MobileRepository(it) }
        val factory = repository?.let { WakalaViewModelFactory(it) }
        wakalaViewModel= factory?.let { ViewModelProvider(this, it).get(WakalaViewModel::class.java) }!!
        binding.myWakalaViewModel=wakalaViewModel
        binding.lifecycleOwner=this
        initRecyclerView()
        return  binding.root
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_wakala, container, false)
    }

//    private fun getMydata() {
//        val service= RetroInstance.getRetroInstance()
//        val retrofitData = service?.getData()
//
//        if (retrofitData != null) {
//            retrofitData.enqueue(object : Callback<List<Wakalaist>?> {
//                override fun onResponse(
//                    call: Call<List<WakalaLst>?>,
//                    response: Response<List<WakalaLst>?>
//                ) {
//                    val responseBody =response.body()
//                    val mystringBuilder = StringBuilder()
//                    if (responseBody != null) {
//                        for (myData in responseBody){
//                           mystringBuilder.append(myData.id)
//                            mystringBuilder.append("\n")
//                        }
//                    }
//                   binding.txtId.text=mystringBuilder
//                    Log.d("WAKALAmy", "oKEY")
//                }
//
//                override fun onFailure(call: Call<List<WakalaLst>?>, t: Throwable) {
//                  Log.d("WAKALAmy", "omFailure: "+t.message)
//                }
//            })
//        }
//        else{
//            Log.d("WAKALA", "omNull")
//        }
//    }


    fun initRecyclerView(){
//        binding.transactionRecyclerView.layoutManager= LinearLayoutManager(this)
        binding.wakalaRecyclerView.layoutManager= LinearLayoutManager(context)
        var mDividerItemDecoration = DividerItemDecoration(
            context, (binding.wakalaRecyclerView.layoutManager as LinearLayoutManager).getOrientation()
        )
        binding.wakalaRecyclerView.addItemDecoration(mDividerItemDecoration)

        displayTransactionList()
    }
    //
    private fun displayTransactionList(){
        wakalaViewModel.wakala.observe(this, Observer {
            Log.i("MYWAKALAMKUU",it.toString())
            binding.wakalaRecyclerView.adapter= RecyclerViewWakala(it) { selectedItem: Wakala ->
                listItemClicked(
                    selectedItem
                )
            }
        })
    }
    private fun listItemClicked(wakala: Wakala){

        wakalaViewModel.updatewakala("0766666666",wakala.wakalaid)
        Toast.makeText(activity, "Hola ratita ${wakala.tigoname}", Toast.LENGTH_SHORT).show()
    }
}