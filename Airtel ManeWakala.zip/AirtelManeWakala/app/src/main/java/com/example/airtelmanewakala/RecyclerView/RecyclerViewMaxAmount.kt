package com.example.airtelmanewakala.RecyclerView

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.airtelmanewakala.R
import com.example.airtelmanewakala.databinding.MaxamountitemlistBinding
import com.example.airtelmanewakala.db.MaxAmount

//class RecyclerViewWakalaMkuu(private val wakalaMkuuList:List<WakalaMkuu>
//,private val clickListener: (WakalaMkuu)->Unit):RecyclerView.Adapter<MyWakalaMkuuViewHolder>()
class RecyclerViewMaxAmount (private val maxAmountList: List<MaxAmount>):RecyclerView.Adapter<MyMaxAmountViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyMaxAmountViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)

        val binding: MaxamountitemlistBinding =
            DataBindingUtil.inflate(layoutInflater, R.layout.maxamountitemlist,parent,false)
        return MyMaxAmountViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyMaxAmountViewHolder, position: Int) {
        holder.bind(maxAmountList[position])
    }

    override fun getItemCount(): Int {
        return maxAmountList.size
    }
}
class MyMaxAmountViewHolder(val binding:MaxamountitemlistBinding):RecyclerView.ViewHolder(binding.root){

    fun bind(maxAmount: MaxAmount){
binding.maxamountAmount.text= maxAmount.amount.toString()
    }
}